<?php
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'brecruiter');
define('GEMAILADDRESS', 'gmail_account@gmail.com');
define('GEMAILPASSWORD', 'yourpassword');
define('MAILERNAME', 'youremaildisplayname');
?>